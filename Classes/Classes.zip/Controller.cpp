#include "Controller.h"

void Controller::setControllerListener(ControllerListener *controllerListener){
	this->m_controllerListener = controllerListener;
}