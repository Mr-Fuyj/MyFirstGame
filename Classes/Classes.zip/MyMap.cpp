#include "MyMap.h"
#include"Global.h"

bool MyMap::init(){
	sGlobal->myMap = this;
	log("�����ֿ�ָ����ߵ�ͼû���л������⣬�������ɵ�ͼ֮ǰ��û���޸�sGlobal->mapNumֵ");
	this->m_map = TMXTiledMap::create(StringUtils::format("scene%d.tmx", sGlobal->mapNum));
	log("��ͼ�����ɹ�����ָ���¼��������ɴ�����");
	this->addChild(m_map,2,sGlobal->mapNum);
	//��ʼ�����͵�
	for (int i = 0; i <= 4; i++){
		this->setPoint((this->transmitPoint[i]), -1, -1);
	}

	//������δ�������ȷ��ÿһ�������µĴ��͵㼰����Ŀ��
	//����ʱ���ϵ���˴����뽫�ᱻд����ʮ�ֳ�ª
	//�Ժ���ʱ���ٸİ�

	switch (sGlobal->mapNum){
	case 0:{
			   this->setPoint((this->transmitPoint[0]), 9, 9);
			   this->setDestination(0, 1, 9, 9);
			   break;
	}
	case 1:{
			   this->setPoint((this->transmitPoint[0]), 9, 9);
			   this->setDestination(0, 0, 9, 9);
			   this->setPoint((this->transmitPoint[1]), 9,10);
			   this->setDestination(1, 2, 9, 10);
			   break;
	}
	case 2:{
			   this->setPoint((this->transmitPoint[0]), 9, 10);
			   this->setDestination(0, 1, 9, 10);
			   this->setPoint((this->transmitPoint[1]), 9, 15);
			   this->setDestination(1, 3, 27, 15);
			   break;
	}
	case 3:{
			   this->setPoint((this->transmitPoint[0]), 27,15);
			   this->setDestination(0, 2,9,15);
			   this->setPoint((this->transmitPoint[1]), 15,17);
			   this->setDestination(1, 5,8,27);
			   this->setPoint((this->transmitPoint[2]), 38,30);
			   this->setDestination(2, 6,3,12);
			   this->setPoint((this->transmitPoint[3]), 13,23);
			   this->setDestination(3, 11,13,6);
			   this->setPoint((this->transmitPoint[4]), 22,36);
			   this->setDestination(4, 4,19,22);
			   break;
	}
	case 4:{
			   this->setPoint((this->transmitPoint[0]), 22,36);
			   this->setDestination(0, 3,22,36);
			   this->setPoint((this->transmitPoint[1]), 10,32);
			   this->setDestination(1, 7,10,32);
			   this->setPoint((this->transmitPoint[2]), 8,18);
			   this->setDestination(2, 10,8,18);
			   this->setPoint((this->transmitPoint[3]), 5,15);
			   this->setDestination(3, 9,5,15);
			   break;
	}
	case 5:{
			   this->setPoint((this->transmitPoint[0]), 8,27);
			   this->setDestination(0, 3,15,11);
			   this->setPoint((this->transmitPoint[1]), 15,12);
			   this->setDestination(1, 12,51,30);
			   this->setPoint((this->transmitPoint[2]), 15,11);
			   this->setDestination(2, 13,9,6);
			   break;
	}
	case 6:{
			   this->setPoint((this->transmitPoint[0]), 3,12);
			   this->setDestination(0, 3,38,30);
			   break;
	}
	case 7:{
			   this->setPoint((this->transmitPoint[0]), 10,32);
			   this->setDestination(0, 4,29,11);
			   this->setPoint((this->transmitPoint[1]), 23,5);
			   this->setDestination(1, 8,0,5);
			   break;
	}
	case 8:{
			   this->setPoint((this->transmitPoint[0]), 0,5);
			   this->setDestination(0, 7,23,5);
			   break;
	}
	case 9:{
			   this->setPoint((this->transmitPoint[0]), 5,15);
			   this->setDestination(0, 4,16,8);
			   break;
	}
	case 10:{
				this->setPoint((this->transmitPoint[0]),8,18);
				this->setDestination(0, 4,22,8);
				break;
	}
	case 11:{
				this->setPoint((this->transmitPoint[0]), 13,6);
				this->setDestination(0, 3,13,23);
				break;
	}
	case 12:{
				this->setPoint((this->transmitPoint[0]), 51,30);
				this->setDestination(0, 5,15,12);
				break;
	}
	case 13:{
				this->setPoint((this->transmitPoint[0]), 9,6);
				this->setDestination(0, 5,15,11);
				break;
	}
	}
	this->setAllNPC();

	return true;


}

void MyMap::setPoint(Point& point, int x, int y){
	point.x = x;
	point.y = y;
}

void MyMap::setDestination(int point, int map, int x, int y){
	this->destination[point].mapNum = map;
	this->destination[point].startPosition.x = x;
	this->destination[point].startPosition.y = y;
}

void MyMap::setNPC(int NumInMap,int NPCNum, int positionX, int positionY, int keyStart, int keyEnd){
	this->npc[NumInMap].keyEnd = keyEnd;
	this->npc[NumInMap].keyStart = keyStart;
	this->npc[NumInMap].NPCNum = NPCNum;
	this->npc[NumInMap].NPCPosition.x = positionX;
	this->npc[NumInMap].NPCPosition.y = positionY;
	this->npc[NumInMap].NumInMap = NumInMap;
}

//void MyMap::changeMap(Point transmitPoint){
//	for (int i = 0; i <= 4; i++){
//		if (transmitPoint == this->transmitPoint[i]){
//			this->removeChildByTag(sGlobal->mapNum);
//			TMXTiledMap*NewMap = TMXTiledMap::create(StringUtils::format("scene%d.tmx", this->destination[i].mapNum));
//			this->addChild(NewMap, 2, this->destination[i].mapNum);
//			sGlobal->hero = Hero::create();
//			Sprite*heroSprite = Sprite::create("Hero_Down_0.png");
//			sGlobal->hero->bindSprite(heroSprite);
//			sGlobal->hero->setPosition(this->positionForTileCoord(this->destination[i].startPosition));
//			NewMap->addChild(sGlobal->hero);
//			sGlobal->map = NewMap;
//			sGlobal->mapNum = this->destination[i].mapNum;
//			break;
//		}
//	}
//}

Point MyMap::positionForTileCoord(Point tileCoord)
{
	Point pos = Point((tileCoord.x * 32), ((this->m_map->getMapSize().height - tileCoord.y - 1) * this->m_map->getTileSize().height));
	return pos;
}


















//�����￪ʼ����д
void MyMap::setAllNPC(){
	//switch (sGlobal->mapNum)  {
	//case 1:{
	//		   //6����ֵ�����ҷֱ�Ϊ��npc�ڵ�ͼ�еı�ţ�0~9���⣬�������ظ�����npc���ܱ��,�������꣨��tmx��ͼ�в��ң����Ի��Ŀ�ʼkeyֵ�ͽ���keyֵ
	//		   //�м���npc��ͬ�ĵ�ͼд����case
	//		   //��Ҫ����break
	//		   this->setNPC(0, 0, 30, 25, 8, 12);
	//		   Sprite* NPC_0 = Sprite::create("npc��pngͼ.png");
	//		   NPC_0->setPosition(Point(30, 25));
	//		   this->m_map->addChild(NPC_0);
	//		   break;
	//}
	//}
}