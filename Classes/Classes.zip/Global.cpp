#include "Global.h"

DECLARE_SINGLETON_MEMBER(Global);

Global::Global(void)
{
	hero = NULL;
	touchPositionGlobal = Point(-1, -1);
	map = NULL;
	menuTouchPosition = Point(-1, -1);
	controllerLayer = NULL;
	moveController = NULL;
	dialogNum = 0;
	mapNum = -1;
	myMap = NULL;
	gameScene = NULL;
}

Global::~Global(void)
{

}